import boto3
import logging
import csv
import rds_config
import pymysql
import sys

s3_client = boto3.client('s3')

rds_host  = "apidb.cisebersdotq.us-east-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
    
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    
    bucket = event['detail']['bucket']['name']
    object = event['detail']['object']['key']
    
    csv_file_obj = s3_client.get_object(Bucket=bucket, Key=object)
    lines = csv_file_obj['Body'].read().decode('utf-8').split('\n')
    
    results = []
    for row in csv.DictReader(lines,fieldnames=['id','department']):
        results.append(row.values())
        
    with conn.cursor() as cur:
        for line in results:
            cur.execute('insert into Employee (EmpID, Name) values({0}, "{1}")'.format(line['id'],line['department']))
            
    conn.commit()

    return "Added items from RDS MySQL table"
    