db_username = "admin"
db_password = "wgnJLZ56"
db_name = "Company_bd" 